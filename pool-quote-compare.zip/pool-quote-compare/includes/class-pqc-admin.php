<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PQC_Admin {

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_action( 'admin_post_pqc_resend_email', [ __CLASS__, 'handle_resend' ] );
		add_action( 'admin_post_pqc_rerun', [ __CLASS__, 'handle_rerun' ] );
	}

	public static function menu() {
		add_menu_page(
			__( 'Pool Quote Compare', 'pool-quote-compare' ),
			__( 'Pool Quotes', 'pool-quote-compare' ),
			'manage_options',
			'pool-quote-compare',
			[ __CLASS__, 'render_settings' ],
			'dashicons-clipboard',
			58
		);
		add_submenu_page(
			'pool-quote-compare',
			__( 'Settings', 'pool-quote-compare' ),
			__( 'Settings', 'pool-quote-compare' ),
			'manage_options',
			'pool-quote-compare',
			[ __CLASS__, 'render_settings' ]
		);
		add_submenu_page(
			'pool-quote-compare',
			__( 'Submissions', 'pool-quote-compare' ),
			__( 'Submissions', 'pool-quote-compare' ),
			'manage_options',
			'pqc-submissions',
			[ __CLASS__, 'render_submissions' ]
		);
	}

	public static function register_settings() {
		register_setting( 'pqc_settings_group', PQC_OPTION_KEY, [
			'sanitize_callback' => [ __CLASS__, 'sanitize' ],
			'default'           => [],
		] );
	}

	public static function sanitize( $input ) {
		$settings = pqc_get_settings();
		$clean = $settings;

		if ( isset( $input['api_key'] ) ) {
			$clean['api_key'] = trim( sanitize_text_field( $input['api_key'] ) );
		}
		if ( isset( $input['companies_house_api_key'] ) ) {
			$clean['companies_house_api_key'] = trim( sanitize_text_field( $input['companies_house_api_key'] ) );
		}
		if ( isset( $input['system_prompt'] ) ) {
			$clean['system_prompt'] = wp_unslash( $input['system_prompt'] );
		}
		if ( isset( $input['model'] ) ) {
			$clean['model'] = sanitize_text_field( $input['model'] );
		}
		if ( isset( $input['max_tokens'] ) ) {
			$clean['max_tokens'] = max( 1024, min( 128000, (int) $input['max_tokens'] ) );
		}
		$clean['enable_web_search'] = ! empty( $input['enable_web_search'] ) ? 1 : 0;
		if ( isset( $input['pdf_extraction_mode'] ) ) {
			$mode = sanitize_text_field( $input['pdf_extraction_mode'] );
			$clean['pdf_extraction_mode'] = in_array( $mode, [ 'text_first', 'pdf_always' ], true ) ? $mode : 'text_first';
		}
		if ( isset( $input['max_file_mb'] ) ) {
			$clean['max_file_mb'] = max( 1, min( 200, (int) $input['max_file_mb'] ) );
		}
		if ( isset( $input['max_files'] ) ) {
			$clean['max_files'] = max( 2, min( 20, (int) $input['max_files'] ) );
		}
		if ( isset( $input['email_from_name'] ) ) {
			$clean['email_from_name'] = sanitize_text_field( $input['email_from_name'] );
		}
		if ( isset( $input['email_from_address'] ) ) {
			$clean['email_from_address'] = sanitize_email( $input['email_from_address'] );
		}
		if ( isset( $input['email_subject'] ) ) {
			$clean['email_subject'] = sanitize_text_field( $input['email_subject'] );
		}
		if ( isset( $input['email_intro'] ) ) {
			$clean['email_intro'] = wp_kses_post( $input['email_intro'] );
		}
		if ( isset( $input['disclaimer'] ) ) {
			$clean['disclaimer'] = wp_kses_post( $input['disclaimer'] );
		}
		if ( isset( $input['thank_you_url'] ) ) {
			$clean['thank_you_url'] = esc_url_raw( trim( $input['thank_you_url'] ) );
		}
		if ( isset( $input['thank_you_heading'] ) ) {
			$clean['thank_you_heading'] = sanitize_text_field( $input['thank_you_heading'] );
		}
		if ( isset( $input['thank_you_message'] ) ) {
			$clean['thank_you_message'] = wp_kses_post( $input['thank_you_message'] );
		}
		$clean['bcc_admin'] = ! empty( $input['bcc_admin'] ) ? 1 : 0;

		return $clean;
	}

	public static function enqueue( $hook ) {
		if ( strpos( (string) $hook, 'pool-quote-compare' ) === false && strpos( (string) $hook, 'pqc-submissions' ) === false ) {
			return;
		}
		wp_enqueue_style( 'pqc-admin', PQC_PLUGIN_URL . 'assets/css/admin.css', [], PQC_VERSION );
	}

	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$settings = pqc_get_settings();
		$default_prompt = pqc_default_system_prompt();
		?>
		<div class="wrap pqc-admin">
			<h1><?php esc_html_e( 'Pool Quote Compare – Settings', 'pool-quote-compare' ); ?></h1>
			<p><?php esc_html_e( 'Configure the Claude Opus 4.7 (1M context) comparison agent. The system prompt shown below is displayed to customers on the upload page for full transparency.', 'pool-quote-compare' ); ?></p>

			<form method="post" action="options.php">
				<?php settings_fields( 'pqc_settings_group' ); ?>

				<h2><?php esc_html_e( 'Claude API', 'pool-quote-compare' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="pqc_api_key"><?php esc_html_e( 'API key', 'pool-quote-compare' ); ?></label></th>
						<td>
							<input type="password" id="pqc_api_key" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[api_key]" value="<?php echo esc_attr( $settings['api_key'] ); ?>" class="regular-text" autocomplete="off" />
							<p class="description"><?php esc_html_e( 'Anthropic API key. Stored in wp_options. Never exposed to the frontend.', 'pool-quote-compare' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_model"><?php esc_html_e( 'Model', 'pool-quote-compare' ); ?></label></th>
						<td>
							<input type="text" id="pqc_model" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[model]" value="<?php echo esc_attr( $settings['model'] ); ?>" class="regular-text" />
							<p class="description"><?php esc_html_e( 'Default: claude-opus-4-7 (Opus 4.7 with 1M context window).', 'pool-quote-compare' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_max_tokens"><?php esc_html_e( 'Max output tokens', 'pool-quote-compare' ); ?></label></th>
						<td>
							<input type="number" id="pqc_max_tokens" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[max_tokens]" value="<?php echo esc_attr( $settings['max_tokens'] ); ?>" min="1024" max="128000" />
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Web search', 'pool-quote-compare' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[enable_web_search]" value="1" <?php checked( 1, $settings['enable_web_search'] ); ?> /> <?php esc_html_e( 'Let the agent use the web_search tool to verify facts (Google reviews, Trustpilot, equipment datasheets, news).', 'pool-quote-compare' ); ?></label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_ch_api_key"><?php esc_html_e( 'Companies House API key', 'pool-quote-compare' ); ?></label></th>
						<td>
							<input type="password" id="pqc_ch_api_key" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[companies_house_api_key]" value="<?php echo esc_attr( $settings['companies_house_api_key'] ); ?>" class="regular-text" autocomplete="off" />
							<p class="description"><?php
								printf(
									esc_html__( 'Free UK Companies House API key (%s). When set, the agent can look up legal entity, incorporation, officers, filings, PSCs and charges for every company named in a quote — authoritative data, not brochure claims.', 'pool-quote-compare' ),
									'<a href="https://developer.company-information.service.gov.uk/" target="_blank" rel="noopener">developer.company-information.service.gov.uk</a>'
								);
							?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Uploads', 'pool-quote-compare' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="pqc_max_file_mb"><?php esc_html_e( 'Max file size (MB)', 'pool-quote-compare' ); ?></label></th>
						<td>
							<input type="number" id="pqc_max_file_mb" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[max_file_mb]" value="<?php echo esc_attr( $settings['max_file_mb'] ); ?>" min="1" max="200" />
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_max_files"><?php esc_html_e( 'Max files per submission', 'pool-quote-compare' ); ?></label></th>
						<td>
							<input type="number" id="pqc_max_files" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[max_files]" value="<?php echo esc_attr( $settings['max_files'] ); ?>" min="2" max="20" />
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_pdf_extraction_mode"><?php esc_html_e( 'PDF handling', 'pool-quote-compare' ); ?></label></th>
						<td>
							<?php $pdftotext = class_exists( 'PQC_Parser' ) ? PQC_Parser::pdftotext_path() : ''; ?>
							<select id="pqc_pdf_extraction_mode" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[pdf_extraction_mode]">
								<option value="text_first" <?php selected( $settings['pdf_extraction_mode'], 'text_first' ); ?>><?php esc_html_e( 'Extract text server-side first (recommended — saves ~70-90% on Claude tokens)', 'pool-quote-compare' ); ?></option>
								<option value="pdf_always" <?php selected( $settings['pdf_extraction_mode'], 'pdf_always' ); ?>><?php esc_html_e( 'Always send the full PDF (preserves images/diagrams, costs more)', 'pool-quote-compare' ); ?></option>
							</select>
							<p class="description">
								<?php if ( $pdftotext !== '' ) : ?>
									<span style="color:#1b5e20;">✓ <?php echo esc_html( sprintf( __( 'pdftotext found at %s — server-side extraction will work.', 'pool-quote-compare' ), $pdftotext ) ); ?></span>
								<?php else : ?>
									<span style="color:#b00020;">⚠ <?php esc_html_e( 'pdftotext is not installed on this server. The plugin will fall back to sending full PDFs. Install Poppler (apt: poppler-utils, yum: poppler-utils, brew: poppler) for cost savings.', 'pool-quote-compare' ); ?></span>
								<?php endif; ?>
								<br/><?php esc_html_e( "If a quote uses image-based diagrams (e.g. dimension drawings) that you want the agent to see, choose 'Always send the full PDF'.", 'pool-quote-compare' ); ?>
							</p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Email delivery', 'pool-quote-compare' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="pqc_email_from_name"><?php esc_html_e( 'From name', 'pool-quote-compare' ); ?></label></th>
						<td><input type="text" id="pqc_email_from_name" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[email_from_name]" value="<?php echo esc_attr( $settings['email_from_name'] ); ?>" class="regular-text" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_email_from_address"><?php esc_html_e( 'From address', 'pool-quote-compare' ); ?></label></th>
						<td><input type="email" id="pqc_email_from_address" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[email_from_address]" value="<?php echo esc_attr( $settings['email_from_address'] ); ?>" class="regular-text" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_email_subject"><?php esc_html_e( 'Subject', 'pool-quote-compare' ); ?></label></th>
						<td><input type="text" id="pqc_email_subject" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[email_subject]" value="<?php echo esc_attr( $settings['email_subject'] ); ?>" class="regular-text" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_email_intro"><?php esc_html_e( 'Email intro', 'pool-quote-compare' ); ?></label></th>
						<td><textarea id="pqc_email_intro" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[email_intro]" rows="3" class="large-text"><?php echo esc_textarea( $settings['email_intro'] ); ?></textarea></td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_disclaimer"><?php esc_html_e( 'Disclaimer', 'pool-quote-compare' ); ?></label></th>
						<td>
							<textarea id="pqc_disclaimer" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[disclaimer]" rows="6" class="large-text"><?php echo esc_textarea( $settings['disclaimer'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Shown at the bottom of the comparison on the webpage and in the email. Covers AI accuracy limitations and the customer\'s duty to verify.', 'pool-quote-compare' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Admin copy', 'pool-quote-compare' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[bcc_admin]" value="1" <?php checked( 1, $settings['bcc_admin'] ); ?> /> <?php esc_html_e( 'BCC the site admin on every customer email.', 'pool-quote-compare' ); ?></label></td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'After-submit thank you', 'pool-quote-compare' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Shown as soon as the customer submits. The actual comparison is delivered by email ~10 minutes later.', 'pool-quote-compare' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="pqc_thank_you_url"><?php esc_html_e( 'Thank-you redirect URL (optional)', 'pool-quote-compare' ); ?></label></th>
						<td>
							<input type="url" id="pqc_thank_you_url" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[thank_you_url]" value="<?php echo esc_attr( $settings['thank_you_url'] ); ?>" class="regular-text" placeholder="https://example.com/thanks" />
							<p class="description"><?php esc_html_e( 'If set, the customer is redirected here after submitting. If blank, the thank-you heading/message below is shown inline.', 'pool-quote-compare' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_thank_you_heading"><?php esc_html_e( 'Inline heading', 'pool-quote-compare' ); ?></label></th>
						<td><input type="text" id="pqc_thank_you_heading" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[thank_you_heading]" value="<?php echo esc_attr( $settings['thank_you_heading'] ); ?>" class="large-text" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="pqc_thank_you_message"><?php esc_html_e( 'Inline message', 'pool-quote-compare' ); ?></label></th>
						<td><textarea id="pqc_thank_you_message" name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[thank_you_message]" rows="4" class="large-text"><?php echo esc_textarea( $settings['thank_you_message'] ); ?></textarea></td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Agent system prompt', 'pool-quote-compare' ); ?></h2>
				<p class="description"><?php esc_html_e( 'This is the system prompt sent to Claude. It is also displayed to customers on the upload page so they can see exactly how their quotes will be analysed.', 'pool-quote-compare' ); ?></p>
				<textarea name="<?php echo esc_attr( PQC_OPTION_KEY ); ?>[system_prompt]" rows="24" class="large-text code"><?php echo esc_textarea( $settings['system_prompt'] ); ?></textarea>
				<p><button type="button" class="button" onclick="document.getElementById('pqc_default_prompt').style.display='block';return false;"><?php esc_html_e( 'Show packaged default', 'pool-quote-compare' ); ?></button></p>
				<pre id="pqc_default_prompt" style="display:none;max-height:300px;overflow:auto;background:#f6f7f7;padding:12px;border:1px solid #ccd0d4;"><?php echo esc_html( $default_prompt ); ?></pre>

				<?php submit_button(); ?>
			</form>

			<h2><?php esc_html_e( 'Shortcode', 'pool-quote-compare' ); ?></h2>
			<p><?php esc_html_e( 'Place this shortcode on any page to show the comparison form:', 'pool-quote-compare' ); ?></p>
			<code>[pool_quote_compare]</code>
		</div>
		<?php
	}

	public static function render_submissions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$view_id = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0;
		if ( $view_id ) {
			self::render_single_submission( $view_id );
			return;
		}

		$rows = PQC_Storage::recent( 200 );
		?>
		<div class="wrap pqc-admin">
			<h1><?php esc_html_e( 'Submissions', 'pool-quote-compare' ); ?></h1>
			<?php if ( ! empty( $_GET['resent'] ) ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Email resent.', 'pool-quote-compare' ); ?></p></div>
			<?php endif; ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th>ID</th>
						<th><?php esc_html_e( 'Date', 'pool-quote-compare' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'pool-quote-compare' ); ?></th>
						<th><?php esc_html_e( 'Email', 'pool-quote-compare' ); ?></th>
						<th><?php esc_html_e( 'Files', 'pool-quote-compare' ); ?></th>
						<th><?php esc_html_e( 'Status', 'pool-quote-compare' ); ?></th>
						<th><?php esc_html_e( 'Tokens / cost', 'pool-quote-compare' ); ?></th>
						<th><?php esc_html_e( 'Emailed', 'pool-quote-compare' ); ?></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="8"><?php esc_html_e( 'No submissions yet.', 'pool-quote-compare' ); ?></td></tr>
					<?php else : foreach ( $rows as $row ) : ?>
						<tr>
							<td>#<?php echo (int) $row->id; ?></td>
							<td><?php echo esc_html( $row->created_at ); ?></td>
							<td><?php echo esc_html( $row->customer_name ); ?></td>
							<td><?php echo esc_html( $row->customer_email ); ?></td>
							<td><?php echo (int) $row->file_count; ?></td>
							<td><?php echo esc_html( $row->status ); ?></td>
							<td><code style="font-size:11px;"><?php echo esc_html( self::format_usage( $row->usage_json ) ); ?></code></td>
							<td><?php echo $row->emailed_at ? esc_html( $row->emailed_at ) : '—'; ?></td>
							<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=pqc-submissions&view=' . (int) $row->id ) ); ?>" class="button button-small"><?php esc_html_e( 'View', 'pool-quote-compare' ); ?></a></td>
						</tr>
					<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private static function render_single_submission( $id ) {
		$row = PQC_Storage::get( $id );
		if ( ! $row ) {
			echo '<div class="wrap"><p>' . esc_html__( 'Submission not found.', 'pool-quote-compare' ) . '</p></div>';
			return;
		}
		$files = json_decode( $row->files_json, true );
		if ( ! is_array( $files ) ) {
			$files = [];
		}
		$usage = json_decode( $row->usage_json, true );
		?>
		<div class="wrap pqc-admin">
			<h1><?php printf( esc_html__( 'Submission #%d', 'pool-quote-compare' ), (int) $row->id ); ?></h1>
			<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=pqc-submissions' ) ); ?>">&larr; <?php esc_html_e( 'Back to list', 'pool-quote-compare' ); ?></a></p>

			<?php if ( ! empty( $_GET['rerun'] ) && $_GET['rerun'] === 'started' ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Re-run started. Refresh this page in a minute or two to see the new response. The customer will be emailed automatically when it finishes.', 'pool-quote-compare' ); ?></p></div>
			<?php elseif ( ! empty( $_GET['rerun'] ) && $_GET['rerun'] === 'missing' ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Could not re-run: the saved quote files are missing on disk.', 'pool-quote-compare' ); ?></p></div>
			<?php elseif ( ! empty( $_GET['resent'] ) ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Email resent.', 'pool-quote-compare' ); ?></p></div>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Customer', 'pool-quote-compare' ); ?></h2>
			<table class="widefat"><tbody>
				<tr><th><?php esc_html_e( 'Submitted', 'pool-quote-compare' ); ?></th><td><?php echo esc_html( $row->created_at ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Name', 'pool-quote-compare' ); ?></th><td><?php echo esc_html( $row->customer_name ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Email', 'pool-quote-compare' ); ?></th><td><?php echo esc_html( $row->customer_email ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Notes', 'pool-quote-compare' ); ?></th><td><?php echo nl2br( esc_html( $row->customer_notes ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'IP', 'pool-quote-compare' ); ?></th><td><?php echo esc_html( $row->ip_address ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Status', 'pool-quote-compare' ); ?></th><td><?php echo esc_html( $row->status ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Emailed', 'pool-quote-compare' ); ?></th><td><?php echo $row->emailed_at ? esc_html( $row->emailed_at ) : '—'; ?></td></tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Uploaded files', 'pool-quote-compare' ); ?></h2>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Filename', 'pool-quote-compare' ); ?></th>
					<th><?php esc_html_e( 'Size', 'pool-quote-compare' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $files as $idx => $f ) :
					$dl_url = wp_nonce_url(
						admin_url( 'admin-ajax.php?action=pqc_download&id=' . (int) $row->id . '&i=' . (int) $idx ),
						'pqc_download_' . (int) $row->id
					);
				?>
					<tr>
						<td><?php echo esc_html( isset( $f['original'] ) ? $f['original'] : '' ); ?></td>
						<td><?php echo esc_html( isset( $f['size'] ) ? size_format( (int) $f['size'] ) : '' ); ?></td>
						<td><a class="button button-small" href="<?php echo esc_url( $dl_url ); ?>"><?php esc_html_e( 'Download', 'pool-quote-compare' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'AI response', 'pool-quote-compare' ); ?></h2>
			<?php if ( ! empty( $row->error_message ) ) : ?>
				<div class="notice notice-error inline"><p><?php echo esc_html( $row->error_message ); ?></p></div>
			<?php endif; ?>
			<div class="pqc-response-box"><?php echo PQC_Markdown::render( (string) $row->response ); ?></div>

			<?php if ( $usage ) : ?>
				<h3><?php esc_html_e( 'Usage', 'pool-quote-compare' ); ?></h3>
				<p><strong><?php esc_html_e( 'Summary:', 'pool-quote-compare' ); ?></strong> <code><?php echo esc_html( self::format_usage( $usage ) ); ?></code> <em style="color:#6c757d;font-size:12px;">(Opus 4.7 rates: $5 / 1M input · $25 / 1M output · cache read ≈ 0.1×)</em></p>
				<pre><?php echo esc_html( wp_json_encode( $usage, JSON_PRETTY_PRINT ) ); ?></pre>
			<?php endif; ?>

			<h2><?php esc_html_e( 'System prompt used', 'pool-quote-compare' ); ?></h2>
			<details><summary><?php esc_html_e( 'Show prompt', 'pool-quote-compare' ); ?></summary>
				<pre style="max-height:400px;overflow:auto;background:#f6f7f7;padding:12px;border:1px solid #ccd0d4;"><?php echo esc_html( $row->system_prompt ); ?></pre>
			</details>

			<h2><?php esc_html_e( 'Actions', 'pool-quote-compare' ); ?></h2>
			<div class="pqc-action-row">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Re-run the AI analysis for this submission? This will overwrite any existing response and email it to the customer.', 'pool-quote-compare' ) ); ?>');">
					<?php wp_nonce_field( 'pqc_rerun_' . $row->id, 'pqc_rerun_nonce' ); ?>
					<input type="hidden" name="action" value="pqc_rerun" />
					<input type="hidden" name="id" value="<?php echo (int) $row->id; ?>" />
					<button class="button button-primary" type="submit"><?php esc_html_e( 'Re-run analysis and email', 'pool-quote-compare' ); ?></button>
					<p class="description"><?php esc_html_e( 'Reprocesses the saved quote files with the current prompt and settings, saves the new response, and emails the customer.', 'pool-quote-compare' ); ?></p>
				</form>

				<?php if ( $row->customer_email && $row->response ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:14px;">
						<?php wp_nonce_field( 'pqc_resend_' . $row->id, 'pqc_resend_nonce' ); ?>
						<input type="hidden" name="action" value="pqc_resend_email" />
						<input type="hidden" name="id" value="<?php echo (int) $row->id; ?>" />
						<button class="button" type="submit"><?php esc_html_e( 'Re-send existing response by email', 'pool-quote-compare' ); ?></button>
						<p class="description"><?php esc_html_e( 'Sends the currently-stored response to the customer without re-running the AI.', 'pool-quote-compare' ); ?></p>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Format a usage_json blob into a short admin-readable string with an
	 * estimated USD cost using Opus 4.7 pricing.
	 */
	private static function format_usage( $usage_json ) {
		if ( empty( $usage_json ) ) {
			return '—';
		}
		$u = is_array( $usage_json ) ? $usage_json : json_decode( $usage_json, true );
		if ( ! is_array( $u ) ) {
			return '—';
		}
		$in    = (int) ( $u['input_tokens']               ?? 0 );
		$out   = (int) ( $u['output_tokens']              ?? 0 );
		$cw    = (int) ( $u['cache_creation_input_tokens'] ?? 0 );
		$cr    = (int) ( $u['cache_read_input_tokens']     ?? 0 );

		// Opus 4.7 published rates: $5 / 1M input, $25 / 1M output.
		// Cache write ~1.25× input, cache read ~0.1× input.
		$cost = ( $in * 5.0 + $cw * 5.0 * 1.25 + $cr * 5.0 * 0.1 + $out * 25.0 ) / 1000000.0;

		$total_in = $in + $cw + $cr;
		$parts    = [];
		$parts[]  = sprintf( 'in: %s', number_format( $total_in ) );
		if ( $cr > 0 ) {
			$parts[] = sprintf( 'cached: %s', number_format( $cr ) );
		}
		$parts[] = sprintf( 'out: %s', number_format( $out ) );
		$parts[] = sprintf( '~$%.3f', $cost );
		return implode( ' · ', $parts );
	}

	public static function handle_rerun() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		check_admin_referer( 'pqc_rerun_' . $id, 'pqc_rerun_nonce' );

		$row = PQC_Storage::get( $id );
		if ( ! $row ) {
			wp_safe_redirect( admin_url( 'admin.php?page=pqc-submissions&rerun=missing' ) );
			exit;
		}

		$files = json_decode( $row->files_json, true );
		if ( ! is_array( $files ) || count( $files ) < 2 ) {
			PQC_Storage::update( $id, [
				'status'        => 'failed',
				'error_message' => __( 'Re-run failed: saved files are missing.', 'pool-quote-compare' ),
			] );
			wp_safe_redirect( admin_url( 'admin.php?page=pqc-submissions&view=' . $id . '&rerun=missing' ) );
			exit;
		}
		foreach ( $files as $f ) {
			if ( empty( $f['path'] ) || ! file_exists( $f['path'] ) ) {
				PQC_Storage::update( $id, [
					'status'        => 'failed',
					'error_message' => __( 'Re-run failed: a saved quote file is missing on disk.', 'pool-quote-compare' ),
				] );
				wp_safe_redirect( admin_url( 'admin.php?page=pqc-submissions&view=' . $id . '&rerun=missing' ) );
				exit;
			}
		}

		$settings = pqc_get_settings();

		// Reset the row so the UI reflects a fresh run, but preserve files + customer fields.
		PQC_Storage::update( $id, [
			'status'        => 'queued',
			'response'      => '',
			'usage_json'    => null,
			'error_message' => null,
			'emailed_at'    => null,
			'system_prompt' => $settings['system_prompt'],
			'model'         => $settings['model'],
		] );

		// Flush the response to the browser, then run the stream in the same process.
		nocache_headers();
		wp_safe_redirect( admin_url( 'admin.php?page=pqc-submissions&view=' . $id . '&rerun=started' ) );

		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		} else {
			@ob_end_flush();
			@flush();
		}

		ignore_user_abort( true );
		@set_time_limit( 0 );
		if ( function_exists( 'session_write_close' ) ) {
			@session_write_close();
		}

		try {
			PQC_Ajax::run_comparison( $id, $files, (string) $row->customer_notes, $settings );
		} catch ( Throwable $e ) {
			PQC_Storage::update( $id, [
				'status'        => 'failed',
				'error_message' => 'Re-run failed: ' . $e->getMessage(),
			] );
		}
		exit;
	}

	public static function handle_resend() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		check_admin_referer( 'pqc_resend_' . $id, 'pqc_resend_nonce' );
		PQC_Ajax::send_customer_email( $id );
		wp_safe_redirect( admin_url( 'admin.php?page=pqc-submissions&view=' . $id . '&resent=1' ) );
		exit;
	}
}
